/**
 * TEC Gate Entry / Exit – Apps Script API backend
 * Used by the Vercel pages: scan.html, desk.html, admin.html, index.html
 *
 * SETUP: paste this file into Extensions > Apps Script of the Google Sheet,
 * run setupSystem() once, copy the API token from the log, then
 * Deploy > New deployment > Web app (Execute as: Me, Access: Anyone).
 */
const CFG = {
  STUDENTS: 'Combined_Students',
  LOGS: 'Gate_Logs',
  OUTINGS: 'Outing_Requests',
  PERMS: 'Staff_Permissions',
  TZ: 'Asia/Kolkata',
  DUP_SECONDS: 10,
  LOOKBACK_ROWS: 6000,
  MAX_QUERY_ROWS: 5000
};
const LOG_HEADERS = ['Timestamp','Barcode_ID','Register_No','Student_Name','Gender','Department','Year','Hostel_Status','Institution','Direction','Gate','Scanned_By','Method','Activity_Type','Reason','Remarks','Books_Taken','Books_Returned'];
const OUTING_HEADERS = ['Request_ID','Created_At','Barcode_ID','Register_No','Student_Name','Department','Reason','Destination','Requested_Departure','Expected_Return','Status','Decision_By','Decision_At','Actual_Departure','Actual_Return','Remarks'];
const PERM_HEADERS = ['Staff_ID','Name','Email','Role','Allowed_Gates','Enabled','Updated_At'];

/* ------------------------------ entry points ------------------------------ */
function doGet() { return json_({ ok: true, service: 'TEC Gate API', time: new Date().toISOString() }); }

function doPost(e) {
  let p;
  try { p = JSON.parse((e && e.postData && e.postData.contents) || '{}'); }
  catch (err) { return json_({ ok: false, message: 'Invalid request.' }); }
  const expected = PropertiesService.getScriptProperties().getProperty('API_TOKEN');
  if (!expected) return json_({ ok: false, message: 'API token not set. Run setupSystem() in Apps Script first.' });
  if (!p.token || String(p.token) !== expected) return json_({ ok: false, message: 'Invalid access token.' });

  const writes = { scan: 1, manualEntry: 1, createOuting: 1, updateOuting: 1, savePermission: 1 };
  const lock = LockService.getScriptLock();
  try {
    if (writes[p.action]) lock.waitLock(20000);
    const fn = ROUTES[p.action];
    if (!fn) return json_({ ok: false, message: 'Unknown action: ' + p.action });
    return json_(fn(p));
  } catch (err) {
    return json_({ ok: false, message: 'Server error: ' + (err && err.message ? err.message : err) });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

const ROUTES = {
  ping: () => ({ ok: true }),
  getStudent: getStudentAction_,
  scan: scanAction_,
  manualEntry: manualEntryAction_,
  queryLogs: queryLogsAction_,
  getDashboard: dashboardAction_,
  generateDailyReport: p => reportAction_('daily', p.date || p.value),
  generateMonthlyReport: p => reportAction_('monthly', p.month || p.value),
  saveFilteredReport: saveFilteredReportAction_,
  listPermissions: () => ({ ok: true, permissions: readTable_(sheet_(CFG.PERMS, PERM_HEADERS)).rows.map(clean_) }),
  savePermission: savePermissionAction_,
  listOutings: listOutingsAction_,
  createOuting: createOutingAction_,
  updateOuting: updateOutingAction_,
  getPendingOutingCount: () => ({ ok: true, pendingCount: readTable_(sheet_(CFG.OUTINGS, OUTING_HEADERS)).rows.filter(r => up_(r.Status) === 'PENDING').length }),
  outingStatus: outingStatusAction_
};

/** Run once from the editor. Creates all sheets, sets timezone and an API token. */
function setupSystem() {
  const ss = ss_();
  ss.setSpreadsheetTimeZone(CFG.TZ);
  if (!ss.getSheetByName(CFG.STUDENTS)) throw new Error('Sheet "' + CFG.STUDENTS + '" not found. Create it with columns: Barcode_ID, Register_No, Student_Name, Gender, Department, Year, Hostel_Status, Institution, Card_Status.');
  sheet_(CFG.LOGS, LOG_HEADERS); sheet_(CFG.OUTINGS, OUTING_HEADERS); sheet_(CFG.PERMS, PERM_HEADERS);
  const props = PropertiesService.getScriptProperties();
  let t = props.getProperty('API_TOKEN');
  if (!t) { t = Utilities.getUuid().replace(/-/g, '').slice(0, 24); props.setProperty('API_TOKEN', t); }
  Logger.log('SETUP COMPLETE. Your API token is: ' + t);
  return t;
}
/** Optional: edit NEW_TOKEN below, then run this to change the token. */
function changeApiToken() {
  const NEW_TOKEN = 'CHANGE-ME-TO-A-LONG-RANDOM-STRING';
  if (NEW_TOKEN.indexOf('CHANGE-ME') === 0 || NEW_TOKEN.length < 12) throw new Error('Edit NEW_TOKEN first (min 12 characters).');
  PropertiesService.getScriptProperties().setProperty('API_TOKEN', NEW_TOKEN);
  Logger.log('Token updated.');
}

/* --------------------------------- helpers -------------------------------- */
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function ss_() {
  const id = PropertiesService.getScriptProperties().getProperty('SHEET_ID');
  const s = id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
  if (!s) throw new Error('No spreadsheet. Use a container-bound script or set the SHEET_ID script property.');
  return s;
}
function up_(v) { return String(v == null ? '' : v).trim().toUpperCase(); }
function str_(v) { return String(v == null ? '' : v).trim(); }
function fmt_(d, f) { return Utilities.formatDate(d, CFG.TZ, f); }
function dayKey_(d) { return fmt_(d, 'yyyy-MM-dd'); }
function toDate_(v) {
  if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
  if (v === '' || v == null) return null;
  const d = new Date(v); return isNaN(d.getTime()) ? null : d;
}
function ser_(v) { return v instanceof Date ? (isNaN(v.getTime()) ? '' : fmt_(v, "yyyy-MM-dd'T'HH:mm:ssXXX")) : v; }
function clean_(row) { const o = {}; Object.keys(row).forEach(k => { if (k !== '_row') o[k] = ser_(row[k]); }); return o; }

function sheet_(name, headers) {
  const ss = ss_();
  let sh = ss.getSheetByName(name);
  const isNew = !sh;
  if (!sh) sh = ss.insertSheet(name);
  const lastCol = sh.getLastColumn();
  const existing = lastCol ? sh.getRange(1, 1, 1, lastCol).getValues()[0].map(str_) : [];
  if (!existing.some(Boolean)) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sh.setFrozenRows(1);
  } else {
    const missing = headers.filter(h => existing.indexOf(h) < 0);
    if (missing.length) sh.getRange(1, existing.length + 1, 1, missing.length).setValues([missing]).setFontWeight('bold');
  }
  if (isNew) {
    [['Timestamp'], ['Created_At'], ['Requested_Departure'], ['Expected_Return'], ['Decision_At'], ['Actual_Departure'], ['Actual_Return'], ['Updated_At']].forEach(c => {
      const i = headers.indexOf(c[0]); if (i >= 0) sh.getRange(2, i + 1, 2000, 1).setNumberFormat('dd-MMM-yyyy HH:mm:ss');
    });
  }
  return sh;
}
function headers_(sh) { return sh.getRange(1, 1, 1, Math.max(1, sh.getLastColumn())).getValues()[0].map(str_); }
function readTable_(sh, lastN) {
  const h = headers_(sh), last = sh.getLastRow();
  if (last < 2) return { headers: h, rows: [] };
  const start = lastN ? Math.max(2, last - lastN + 1) : 2;
  const vals = sh.getRange(start, 1, last - start + 1, h.length).getValues();
  const rows = vals.map((r, i) => { const o = { _row: start + i }; h.forEach((k, j) => { if (k) o[k] = r[j]; }); return o; });
  return { headers: h, rows };
}
function appendObj_(sh, obj) {
  const h = headers_(sh);
  sh.appendRow(h.map(k => obj[k] === undefined || obj[k] === null ? '' : obj[k]));
}
function updateObj_(sh, rowNum, obj) {
  const h = headers_(sh);
  Object.keys(obj).forEach(k => { const c = h.indexOf(k); if (c >= 0) sh.getRange(rowNum, c + 1).setValue(obj[k]); });
}

/* -------------------------------- students -------------------------------- */
function rowToStudent_(sh, rowNum) {
  const v = sh.getRange(rowNum, 1, 1, 9).getValues()[0];
  const status = str_(v[8]);
  return { barcode: str_(v[0]), reg: str_(v[1]), name: str_(v[2]), gender: str_(v[3]), dept: str_(v[4]), year: str_(v[5]), hostel: str_(v[6]), inst: str_(v[7]), status: status || 'ACTIVE', active: !status || up_(status) === 'ACTIVE' };
}
function findStudent_(raw) {
  const code = str_(raw);
  if (!code) return null;
  const sh = ss_().getSheetByName(CFG.STUDENTS);
  if (!sh) throw new Error('Sheet "' + CFG.STUDENTS + '" not found.');
  const last = sh.getLastRow();
  if (last < 2) return null;
  const tries = [code]; if (!/^stu/i.test(code)) tries.push('STU' + code);
  const want = tries.map(up_);
  const vals = sh.getRange(2, 1, last - 1, 2).getValues();   // exact match on Barcode_ID, then Register_No
  for (let col = 0; col < 2; col++)
    for (let i = 0; i < vals.length; i++)
      if (want.indexOf(up_(vals[i][col])) >= 0) return rowToStudent_(sh, i + 2);
  return null;
}
function isHostel_(s) { return /hostel/i.test(s.hostel) && !/day/i.test(s.hostel); }

function getStudentAction_(p) {
  const s = findStudent_(p.code || p.barcode);
  if (!s) return { ok: true, found: false, message: 'Student not found. Check the barcode and try again.' };
  if (!s.active) return { ok: true, found: true, student: s, message: 'ID card status is "' + s.status + '". Entry/exit is not allowed.' };
  return { ok: true, found: true, student: s };
}

/* ------------------------------- gate logging ------------------------------ */
function lastLogFor_(barcode) {
  const sh = sheet_(CFG.LOGS, LOG_HEADERS), last = sh.getLastRow();
  if (last < 2) return null;
  const h = headers_(sh), n = Math.min(CFG.LOOKBACK_ROWS, last - 1), start = last - n + 1;
  const get = name => sh.getRange(start, h.indexOf(name) + 1, n, 1).getValues();
  const b = get('Barcode_ID'), t = get('Timestamp'), d = get('Direction');
  const key = up_(barcode);
  for (let i = n - 1; i >= 0; i--)
    if (up_(b[i][0]) === key) return { dir: up_(d[i][0]), ts: toDate_(t[i][0]) };
  return null;
}
function decideDirection_(mode, last, forced) {
  mode = up_(mode) || 'AUTO';
  if (mode === 'IN' || mode === 'OUT') return mode;
  if (mode === 'MANUAL') return up_(forced) === 'OUT' ? 'OUT' : up_(forced) === 'IN' ? 'IN' : '';
  if (!last || !last.ts || dayKey_(last.ts) !== dayKey_(new Date())) return 'IN';   // first scan of a new day = IN
  return last.dir === 'IN' ? 'OUT' : 'IN';
}

function record_(s, direction, o) {
  const now = new Date();
  const sh = sheet_(CFG.LOGS, LOG_HEADERS);
  appendObj_(sh, {
    Timestamp: now, Barcode_ID: s.barcode, Register_No: s.reg, Student_Name: s.name, Gender: s.gender, Department: s.dept,
    Year: s.year, Hostel_Status: s.hostel, Institution: s.inst, Direction: direction, Gate: o.gate || 'Main Gate',
    Scanned_By: o.device || 'Security Desk', Method: o.method || 'SCAN', Activity_Type: o.activity || 'Gate Entry',
    Reason: o.reason || '', Remarks: o.remarks || '', Books_Taken: o.booksTaken || 0, Books_Returned: o.booksReturned || 0
  });
  return now;
}

function core_(p, opts) {
  const s = findStudent_(p.code || p.barcode);
  if (!s) return { ok: false, message: 'Student not found. Check the barcode and try again.' };
  if (!s.active) return { ok: false, student: s, message: 'ID card is "' + s.status + '". Entry/exit not recorded.' };

  const last = lastLogFor_(s.barcode);
  const direction = decideDirection_(p.mode, last, p.direction);
  if (!direction) return { ok: false, student: s, message: 'Choose ENTRY (IN) or EXIT (OUT).' };

  if (!opts.admin && last && last.ts && (Date.now() - last.ts.getTime()) < CFG.DUP_SECONDS * 1000 && (up_(p.mode) === 'AUTO' || last.dir === direction))
    return { ok: false, duplicate: true, student: s, message: 'Duplicate scan ignored (scanned less than ' + CFG.DUP_SECONDS + ' seconds ago).' };

  const extra = { gate: p.gate, device: p.device, method: opts.admin ? 'MANUAL' : 'SCAN', activity: p.activity, reason: p.reason, remarks: p.remarks, booksTaken: p.booksTaken, booksReturned: p.booksReturned };
  const hostel = isHostel_(s);
  let outing = null;

  if (hostel && !opts.admin) {
    const list = readTable_(sheet_(CFG.OUTINGS, OUTING_HEADERS), 800).rows.filter(r => up_(r.Barcode_ID) === up_(s.barcode));
    const now = Date.now();
    if (direction === 'OUT') {
      outing = list.filter(r => up_(r.Status) === 'APPROVED').filter(r => {
        const exp = toDate_(r.Expected_Return);
        return r.Actual_Departure || !exp || exp.getTime() >= now;
      }).pop();
      if (!outing) {
        if (!list.some(r => up_(r.Status) === 'PENDING')) createOuting_(s, { reason: 'Gate exit request', remarks: 'Auto-created from gate scan' });
        return { ok: false, pending: true, student: s, direction, message: 'Hostel student: exit permission is required. A request has been sent to the Warden/Admin. Wait for approval, then scan again.' };
      }
      extra.activity = 'Permission / Outing'; extra.reason = outing.Reason; extra.remarks = 'Outing ' + outing.Request_ID;
    } else {
      outing = list.filter(r => up_(r.Status) === 'APPROVED' && r.Actual_Departure).pop();
    }
  }

  const ts = record_(s, direction, extra);
  let note = '';
  if (outing) {
    const sh = sheet_(CFG.OUTINGS, OUTING_HEADERS);
    if (direction === 'OUT' && !outing.Actual_Departure) updateObj_(sh, outing._row, { Actual_Departure: ts });
    if (direction === 'IN') {
      updateObj_(sh, outing._row, { Status: 'RETURNED', Actual_Return: ts });
      const exp = toDate_(outing.Expected_Return);
      if (exp && ts > exp) note = ' (returned late)';
    }
  }
  return { ok: true, direction, student: s, timestamp: fmt_(ts, 'dd MMM yyyy, hh:mm:ss a'), gate: p.gate || 'Main Gate', message: note };
}

function scanAction_(p) { return core_(p, { admin: false }); }
function manualEntryAction_(p) { return core_(Object.assign({}, p, { mode: 'MANUAL' }), { admin: true }); }

/* --------------------------------- queries -------------------------------- */
function yearNum_(v) {
  const s = up_(v), m = s.match(/\b(IV|III|II|I)\b/);
  if (m) return { I: '1', II: '2', III: '3', IV: '4' }[m[1]];
  const d = s.match(/\d/); return d ? d[0] : s;
}
function allLogs_() { return readTable_(sheet_(CFG.LOGS, LOG_HEADERS)).rows; }
function applyFilters_(rows, f) {
  f = f || {};
  const has = (v, q) => up_(v).indexOf(up_(q)) >= 0;
  return rows.filter(r => {
    const d = toDate_(r.Timestamp); if (!d) return false;
    const k = dayKey_(d);
    if (f.fromDate && k < f.fromDate) return false;
    if (f.toDate && k > f.toDate) return false;
    if (f.student && !(has(r.Student_Name, f.student) || has(r.Barcode_ID, f.student) || has(r.Register_No, f.student))) return false;
    if (f.direction && up_(r.Direction) !== up_(f.direction)) return false;
    if (f.activity && up_(r.Activity_Type) !== up_(f.activity)) return false;
    if (f.reason && !(has(r.Reason, f.reason) || has(r.Remarks, f.reason))) return false;
    if (f.gate && !has(r.Gate, f.gate)) return false;
    if (f.department && !has(r.Department, f.department)) return false;
    if (f.year && yearNum_(r.Year) !== yearNum_(f.year)) return false;
    if (f.method && up_(r.Method || 'SCAN') !== up_(f.method)) return false;
    return true;
  });
}
function queryLogsAction_(p) {
  let rows = applyFilters_(allLogs_(), p.filters);
  const total = rows.length, truncated = total > CFG.MAX_QUERY_ROWS;
  if (truncated) rows = rows.slice(-CFG.MAX_QUERY_ROWS);
  rows.forEach(r => { if (!r.Method) r.Method = 'SCAN'; });
  return { ok: true, logs: rows.map(clean_), total, truncated };
}

function dashboardAction_() {
  const sh = sheet_(CFG.LOGS, LOG_HEADERS);
  const rows = readTable_(sh, CFG.LOOKBACK_ROWS).rows, today = dayKey_(new Date());
  const tr = rows.filter(r => { const d = toDate_(r.Timestamp); return d && dayKey_(d) === today; });
  const lastBy = {};
  tr.forEach(r => { lastBy[up_(r.Barcode_ID)] = r; });
  const now = Date.now();
  const activeOut = Object.keys(lastBy).map(k => lastBy[k]).filter(r => up_(r.Direction) === 'OUT')
    .map(r => ({ name: r.Student_Name, registerNo: r.Register_No, department: r.Department, timestamp: ser_(toDate_(r.Timestamp)), gate: r.Gate, durationMinutes: Math.max(0, Math.round((now - toDate_(r.Timestamp).getTime()) / 60000)) }))
    .sort((a, b) => b.durationMinutes - a.durationMinutes);
  const gates = {}; tr.forEach(r => { gates[up_(r.Gate)] = 1; });
  const recentEvents = tr.slice(-15).reverse().map(r => ({ timestamp: ser_(toDate_(r.Timestamp)), name: r.Student_Name, registerNo: r.Register_No, direction: up_(r.Direction), gate: r.Gate, method: r.Method || 'SCAN', activity: r.Activity_Type || 'Gate Entry' }));
  return { ok: true, dashboard: {
    todayTotal: tr.length, todayIn: tr.filter(r => up_(r.Direction) === 'IN').length, todayOut: tr.filter(r => up_(r.Direction) === 'OUT').length,
    activeOut, gatesToday: Object.keys(gates).length, recentEvents } };
}

/* --------------------------------- reports -------------------------------- */
function pairDurations_(rows) {            // OUT -> next IN for the same student; returns Map(row -> minutes)
  const open = {}, dur = new Map();
  rows.forEach(r => {
    const k = up_(r.Barcode_ID), d = up_(r.Direction), t = toDate_(r.Timestamp);
    if (!t) return;
    if (d === 'OUT') open[k] = { r, t };
    else if (d === 'IN' && open[k]) { dur.set(open[k].r, Math.round((t - open[k].t) / 60000)); delete open[k]; }
  });
  return { dur, open };
}
function tally_(rows, keyFn) {
  const m = {};
  rows.forEach(r => { const k = keyFn(r) || '—'; (m[k] = m[k] || { ids: {}, IN: 0, OUT: 0 }); m[k].ids[up_(r.Barcode_ID)] = 1; m[k][up_(r.Direction)] = (m[k][up_(r.Direction)] || 0) + 1; });
  return m;
}
function reportAction_(kind, value) {
  const daily = kind === 'daily';
  if (!(daily ? /^\d{4}-\d{2}-\d{2}$/ : /^\d{4}-\d{2}$/).test(value || '')) return { ok: false, message: daily ? 'Select a valid date.' : 'Select a valid month (yyyy-mm).' };
  const all = allLogs_().filter(r => toDate_(r.Timestamp));
  const rows = all.filter(r => dayKey_(toDate_(r.Timestamp)).indexOf(value) === 0);
  const unique = {}; rows.forEach(r => { unique[up_(r.Barcode_ID)] = 1; });
  const ins = rows.filter(r => up_(r.Direction) === 'IN').length, outs = rows.filter(r => up_(r.Direction) === 'OUT').length;
  const pd = pairDurations_(rows);
  const stillOut = Object.keys(pd.open).map(k => pd.open[k].r);
  const summary = [['Total scans', rows.length], ['Unique students', Object.keys(unique).length], ['Entries (IN)', ins], ['Exits (OUT)', outs],
                   ['Manual records', rows.filter(r => up_(r.Method) === 'MANUAL').length], [daily ? 'Still OUT at end of day' : 'Open OUT records', stillOut.length]];
  const dep = tally_(rows, r => r.Department);
  const deptTable = { title: 'Department-wise movement', headers: ['Department', 'Unique_Students', 'IN', 'OUT'],
    rows: Object.keys(dep).sort().map(k => [k, Object.keys(dep[k].ids).length, dep[k].IN, dep[k].OUT]) };
  const tables = [];
  if (daily) {
    tables.push(deptTable);
    tables.push({ title: 'Students still OUT', headers: ['Student', 'Register_No', 'Department', 'Last_OUT', 'Gate'],
      rows: stillOut.map(r => [r.Student_Name, r.Register_No, r.Department, fmt_(toDate_(r.Timestamp), 'hh:mm:ss a'), r.Gate]) });
    tables.push({ title: 'All movements', headers: ['Time', 'Student', 'Register_No', 'Department', 'Year', 'Hostel', 'Direction', 'Gate', 'Method', 'OUT_Minutes'],
      rows: rows.map(r => [fmt_(toDate_(r.Timestamp), 'hh:mm:ss a'), r.Student_Name, r.Register_No, r.Department, r.Year, r.Hostel_Status, up_(r.Direction), r.Gate, r.Method || 'SCAN', pd.dur.has(r) ? pd.dur.get(r) : '']) });
  } else {
    const days = tally_(rows, r => dayKey_(toDate_(r.Timestamp)));
    tables.push({ title: 'Day-wise summary', headers: ['Date', 'Scans', 'Unique_Students', 'IN', 'OUT'],
      rows: Object.keys(days).sort().map(k => [k, days[k].IN + days[k].OUT, Object.keys(days[k].ids).length, days[k].IN, days[k].OUT]) });
    tables.push(deptTable);
    const st = {};
    rows.forEach(r => { const k = up_(r.Barcode_ID); const o = st[k] = st[k] || { r, days: {}, IN: 0, OUT: 0, mins: 0 };
      o.days[dayKey_(toDate_(r.Timestamp))] = 1; o[up_(r.Direction)] = (o[up_(r.Direction)] || 0) + 1; if (pd.dur.has(r)) o.mins += pd.dur.get(r); });
    tables.push({ title: 'Student-wise summary', headers: ['Register_No', 'Student', 'Department', 'Days_Active', 'IN', 'OUT', 'Total_OUT_Minutes'],
      rows: Object.keys(st).map(k => st[k]).sort((a, b) => b.OUT - a.OUT).map(o => [o.r.Register_No, o.r.Student_Name, o.r.Department, Object.keys(o.days).length, o.IN, o.OUT, o.mins]) });
  }
  const report = { ok: true, title: daily ? 'Daily Report' : 'Monthly Report', period: value, generatedAt: fmt_(new Date(), 'dd MMM yyyy, hh:mm a'), summary, tables };
  try { report.savedTo = writeReportSheet_(daily ? 'Report_Daily' : 'Report_Monthly', report); }
  catch (e) { report.saveError = e.message; }
  return report;
}
function writeReportSheet_(name, r) {
  const ss = ss_(); const sh = ss.getSheetByName(name) || ss.insertSheet(name);
  const out = [[r.title], ['Period', r.period], ['Generated', r.generatedAt], []];
  r.summary.forEach(s => out.push(s));
  r.tables.forEach(t => { out.push([], [t.title], t.headers); t.rows.forEach(x => out.push(x)); });
  const w = Math.max.apply(null, out.map(x => x.length).concat([1]));
  sh.clear();
  sh.getRange(1, 1, out.length, w).setNumberFormat('@').setValues(out.map(x => x.concat(new Array(w - x.length).fill(''))));
  sh.getRange(1, 1).setFontWeight('bold').setFontSize(14);
  return name;
}
function saveFilteredReportAction_(p) {
  const rows = p.rows || [];
  if (!rows.length) return { ok: false, message: 'No rows to save.' };
  const cols = []; rows.forEach(r => Object.keys(r).forEach(k => { if (cols.indexOf(k) < 0) cols.push(k); }));
  const ss = ss_(); const sh = ss.getSheetByName('Report_Filtered') || ss.insertSheet('Report_Filtered');
  sh.clear();
  const out = [[p.title || 'Filtered Gate Report'], ['Generated', fmt_(new Date(), 'dd MMM yyyy, hh:mm a')], ['Filters', JSON.stringify(p.filters || {})], [], cols]
    .concat(rows.map(r => cols.map(c => r[c] == null ? '' : r[c])));
  const w = cols.length;
  sh.getRange(1, 1, out.length, w).setNumberFormat('@').setValues(out.map(x => x.concat(new Array(Math.max(0, w - x.length)).fill('')).slice(0, w)));
  return { ok: true, sheet: 'Report_Filtered', rows: rows.length };
}

/* ---------------------------- staff permissions ---------------------------- */
function savePermissionAction_(p) {
  const x = p.permission || {};
  if (!str_(x.staffId) || !str_(x.name)) return { ok: false, message: 'Staff ID and name are required.' };
  const sh = sheet_(CFG.PERMS, PERM_HEADERS), t = readTable_(sh);
  const found = t.rows.filter(r => up_(r.Staff_ID) === up_(x.staffId))[0];
  const obj = { Staff_ID: str_(x.staffId), Name: str_(x.name), Email: str_(x.email), Role: str_(x.role), Allowed_Gates: str_(x.allowedGates), Enabled: x.enabled === false || x.enabled === 'false' ? 'false' : 'true', Updated_At: new Date() };
  if (found) updateObj_(sh, found._row, obj); else appendObj_(sh, obj);
  return { ok: true };
}

/* ------------------------------ outing requests ----------------------------- */
function createOuting_(s, o) {
  const sh = sheet_(CFG.OUTINGS, OUTING_HEADERS), now = new Date();
  const id = 'OUT-' + fmt_(now, 'yyMMdd-HHmmss') + '-' + Math.floor(10 + Math.random() * 90);
  appendObj_(sh, { Request_ID: id, Created_At: now, Barcode_ID: s.barcode, Register_No: s.reg, Student_Name: s.name, Department: s.dept,
    Reason: o.reason || '', Destination: o.destination || '', Requested_Departure: toDate_(o.requestedDeparture) || now, Expected_Return: toDate_(o.expectedReturn) || '',
    Status: 'PENDING', Remarks: o.remarks || '' });
  return id;
}
function createOutingAction_(p) {
  const o = p.outing || {};
  const s = findStudent_(o.barcode);
  if (!s) return { ok: false, message: 'Student not found.' };
  if (!s.active) return { ok: false, message: 'ID card is not active.' };
  return { ok: true, requestId: createOuting_(s, o) };
}
function listOutingsAction_() {
  const rows = readTable_(sheet_(CFG.OUTINGS, OUTING_HEADERS), 500).rows.reverse().map(clean_);
  return { ok: true, outings: rows };
}
function updateOutingAction_(p) {
  const status = up_(p.status);
  if (['APPROVED', 'REJECTED', 'RETURNED', 'CANCELLED'].indexOf(status) < 0) return { ok: false, message: 'Invalid status.' };
  const sh = sheet_(CFG.OUTINGS, OUTING_HEADERS);
  const r = readTable_(sh).rows.filter(x => str_(x.Request_ID) === str_(p.requestId))[0];
  if (!r) return { ok: false, message: 'Request not found.' };
  const cur = up_(r.Status), ok = { APPROVED: ['PENDING'], REJECTED: ['PENDING'], RETURNED: ['APPROVED'], CANCELLED: ['PENDING', 'APPROVED'] };
  if (ok[status].indexOf(cur) < 0) return { ok: false, message: 'Cannot change a ' + cur + ' request to ' + status + '.' };
  const upd = { Status: status, Decision_By: p.actor || '', Decision_At: new Date() };
  if (status === 'RETURNED') upd.Actual_Return = new Date();
  if (p.remarks) upd.Remarks = p.remarks;
  updateObj_(sh, r._row, upd);
  return { ok: true };
}
function outingStatusAction_(p) {
  const s = findStudent_(p.code || p.barcode);
  if (!s) return { ok: false, message: 'Student not found.' };
  const mine = readTable_(sheet_(CFG.OUTINGS, OUTING_HEADERS), 300).rows.filter(r => up_(r.Barcode_ID) === up_(s.barcode)).pop();
  return { ok: true, status: mine ? up_(mine.Status) : '', approver: mine ? mine.Decision_By : '' };
}
